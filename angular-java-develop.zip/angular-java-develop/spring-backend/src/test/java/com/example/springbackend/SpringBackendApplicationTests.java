package com.example.springbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
