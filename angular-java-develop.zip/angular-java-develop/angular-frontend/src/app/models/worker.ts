export class Worker {
    
    id!: Number;
    workerFName: string = '';
    workerLName: string = '';
    status: string = '';

}
